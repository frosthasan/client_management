        <div class="footer">
            <p>Vehicle Management System Dashboard &copy; 2023. All rights reserved.</p>
        </div>
<?php /**PATH C:\xampp\htdocs\client_management\resources\views/layouts/inc/footer.blade.php ENDPATH**/ ?>