        <div class="header">
            <button class="mobile-toggle" id="mobileToggle">
                <i class="fas fa-bars"></i>
            </button>
            <h1>Vehicle Management System Dashboard</h1>
            <div class="user-info">
                <span>Admin User</span>
                <div class="avatar">AU</div>
            </div>
        </div>
<?php /**PATH C:\xampp\htdocs\client_management\resources\views/layouts/inc/header.blade.php ENDPATH**/ ?>